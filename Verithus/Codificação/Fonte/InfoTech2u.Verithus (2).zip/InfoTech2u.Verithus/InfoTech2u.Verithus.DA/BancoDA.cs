﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InfoTech2u.Verithus.Util;
using InfoTech2u.Verithus.VO;

namespace InfoTech2u.Verithus.DA
{
    public class BancoDA
    {
    }
}
