﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InfoTech2u.Verithus.WEB.Base
{
    public class PaginaBase
    {
    }
}